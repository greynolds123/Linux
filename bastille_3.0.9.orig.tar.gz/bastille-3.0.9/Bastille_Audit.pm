#!/usr/bin/perl

##########################################################################
#
# This is the code implementing the Bastille auditing functionality.
#
# Copyright (C) 2005 Jay Beale
# Licensed under the GNU General Public License
#
# The do_Bastille function is a stub...
##########################################################################



##########################################
# Bastille Audit Functionality           #
##########################################

use API;   

sub do_Bastille {

}

1;
