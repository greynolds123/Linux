# Copyright 2003 Jay Beale
# This file contains all of the Mac OS X-specific subroutines

####################################################################
#
#  This module makes up the MAC OS X-specific API routines.
#  
####################################################################
#
#  Subroutine Listing:
#     &OSX_ConfigureForDistro: 	adds all used file names to global
#                             	hashes 
#

sub OSX_ConfigureForDistro {
    
    return;
    
    
    $GLOBAL_BIN{"md5sum"}="/usr/bin/md5sum";
    
    $GLOBAL_FILE{"sendmail.cf"}="/etc/sendmail.cf"; 
    $GLOBAL_FILE{"banners_makefile"}="/usr/share/doc/tcp_wrappers-7.6/Banners.Makefile";
	
}      

1;
