# Copyright (C) 2005 Jay Beale
# Copyright (C) 2005 Charlie Long, Delphi Research
# Licensed under the GNU General Public License


#######################################################################
##                          lpr/lpd and cups 
#######################################################################

require Bastille::API;
import Bastille::API;

#To see if the lpr service is turned off
$GLOBAL_TEST{'Printing'}{'printing'} =
    sub { 
	return &B_is_service_off("lpd");
    };

#To see if the cupsd service is turned off

$GLOBAL_TEST{'Printing'}{'printing_cups'} =
    sub { 
	return &B_is_service_off("cups");
    };

#To see if the cups-lpd service is off
$GLOBAL_TEST{'Printing'}{'printing_cups_lpd_legacy'} =
    sub { 
	return &B_is_service_off("cups-lpd");
    };

1;
