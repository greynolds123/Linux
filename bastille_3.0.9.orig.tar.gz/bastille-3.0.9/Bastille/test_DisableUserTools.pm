# Copyright (C) 1999 - 2005 Jay Beale
# Licensed under the GNU General Public License

#######################################################################
##                 Test for Disabled User Space Tools                ##
#######################################################################

require Bastille::API;
import Bastille::API;

$GLOBAL_TEST{'DisableUserTools'}{'compiler'} =
    sub {

	# If gcc is executable, ask the question.
        my $gcc = &getGlobal('FILE','gcc');	
	if ( -e $gcc ) {
	    if (&B_check_permissions($gcc,0700)) {
		return $ASKQ;
	    }
	}
	
	# If g++ is executable, ask the question.
	my $g_plus_plus = &getGlobal('FILE','g++');
	if ( -e $g_plus_plus ) {
	    if (&B_check_permissions($g_plus_plus,0700)) {
		return $ASKQ;
	    }
	}

	# Otherwise, skip.
	return $SKIPQ;
	
    };

1;



